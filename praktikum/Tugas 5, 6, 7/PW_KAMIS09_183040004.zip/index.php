<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>183040004</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>
        body {
            margin: 0 auto;
            text-align: center;
        }

        td {
            padding: 0 35px;
        }

        table {
            display: inline-block;
        }
    </style>
</head>
<body>
    <table border="1px solid black" cellpadding="3">
        <tr>
            <td colspan="2">
                <h1>Pertemuan 5</h1>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Latihan 5a</h4>
            </td>
            <td>
                <h5><a href="pertemuan5/Latihan5a.php">Latihan 5a</a></h5>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Latihan 5b</h4>
            </td>
            <td>
                <h5><a href="pertemuan5/Latihan5b.php">Latihan 5b</a></h5>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Latihan 5c</h4>
            </td>
            <td>
                <h5><a href="pertemuan5/Latihan5c.php">Latihan 5c</a></h5>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Latihan 5d</h4>
            </td>
            <td>
                <h5><a href="pertemuan5/Latihan5d.php">Latihan 5d</a></h5>
            </td>
        </tr>
    </table>

    <table border="1px solid black" cellpadding="3">
        <tr>
            <td colspan="2">
                <h1>Pertemuan 6</h1>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Function</h4>
            </td>
            <td>
                <h5><a href="pertemuan6/latihano/function.php">Function</a></h5>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Latihan 6a</h4>
            </td>
            <td>
                <h5><a href="pertemuan6/latihano/latihan6a.php">Latihan 6a</a></h5>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Latihan 6b</h4>
            </td>
            <td>
                <h5><a href="pertemuan6/latihano/latihan6b.php">Latihan 6b</a></h5>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Latihan 6c</h4>
            </td>
            <td>
                <h5><a href="pertemuan6/latihano/latihan6c.php">Latihan 6c</a></h5>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Profil</h4>
            </td>
            <td>
                <h5><a href="pertemuan6/latihano/profil.php">Profil</a></h5>
            </td>
        </tr>
    </table>

    <table border="1px solid black" cellpadding="3">
        <tr>
            <td colspan="2">
                <h1>Pertemuan 7</h1>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Latihan 7a</h4>
            </td>
            <td>
                <h5><a href="pertemuan7/latihan7a">Latihan 7a</a></h5>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Latihan 7b</h4>
            </td>
            <td>
                <h5><a href="pertemuan7/latihan7b">Latihan 7b</a></h5>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Latihan 7c</h4>
            </td>
            <td>
                <h5><a href="pertemuan7/latihan7c">Latihan 7c</a></h5>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Latihan 7d</h4>
            </td>
            <td>
                <h5><a href="pertemuan7/latihan7d">Latihan 7d</a></h5>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Latihan 7e</h4>
            </td>
            <td>
                <h5><a href="pertemuan7/latihan7e">Latihan 7e</a></h5>
            </td>
        </tr>
		
		<tr>
            <td>
                <h4>Tugas 3</h4>
            </td>
            <td>
                <h5><a href="pertemuan7/Tugas3/frontend.php">Tugas 3</a></h5>
            </td>
        </tr>
    </table>
</body>
</html>