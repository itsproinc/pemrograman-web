<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>184040004</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>
        body {
            margin: 0 auto;
            text-align: center;
        }

        td {
            padding: 0 35px;
        }

        table {
            display: inline-block;
        }
    </style>
</head>
<body>
    <table border="1px solid black" cellpadding="3">
        <tr>
            <td colspan="2">
                <h1>Pertemuan 3</h1>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Latihan 3a</h4>
            </td>
            <td>
                <h5><a href="pertemuan3/Latihan3a.php" target="_blank">Latihan 3a</a></h5>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Latihan 3b</h4>
            </td>
            <td>
                <h5><a href="pertemuan3/Latihan3b.php" target="_blank">Latihan 3b</a></h5>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Latihan 3c</h4>
            </td>
            <td>
                <h5><a href="pertemuan3/Latihan3c.php" target="_blank">Latihan 3c</a></h5>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Latihan 3d</h4>
            </td>
            <td>
                <h5><a href="pertemuan3/Latihan3d.php" target="_blank">Latihan 3d</a></h5>
            </td>
        </tr>
    </table>

    <table border="1px solid black" cellpadding="3">
        <tr>
            <td colspan="2">
                <h1>Pertemuan 4</h1>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Latihan 4a</h4>
            </td>
            <td>
                <h5><a href="pertemuan4/Latihan4a.php" target="_blank">Latihan 4a</a></h5>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Latihan 4b</h4>
            </td>
            <td>
                <h5><a href="pertemuan4/Latihan4b.php" target="_blank">Latihan 4b</a></h5>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Latihan 4c</h4>
            </td>
            <td>
                <h5><a href="pertemuan4/Latihan4c.php" target="_blank">Latihan 4c</a></h5>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Latihan 4d</h4>
            </td>
            <td>
                <h5><a href="pertemuan4/Latihan4d.php" target="_blank">Latihan 4d</a></h5>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Associative</h4>
            </td>
            <td>
                <h5><a href="pertemuan4/associative.php" target="_blank">Associative</a></h5>
            </td>
        </tr>

        <tr>
            <td>
                <h4>Tugas 2</h4>
            </td>
            <td>
                <h5><a href="pertemuan4/Tugas2.php" target="_blank">Tugas2</a></h5>
            </td>
        </tr>
    </table>
</body>
</html>